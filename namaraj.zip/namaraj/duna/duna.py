n=int(input("Enter the number of Duna:"))
for i in range(1,11):
    print(n,"x",i,"=",n*i)
